package com.ultraenchants.enchantments;

import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1886;
import net.minecraft.class_1887;

/**
 * Classe de base pour tous les enchantements UltraEnchants.
 * Simplifie la création de nouveaux enchantements.
 */
public abstract class BaseEnchantment extends class_1887 {

    protected final int maxLevel;

    protected BaseEnchantment(class_1888 rarity, class_1886 target, int maxLevel, class_1304... slots) {
        super(rarity, target, slots);
        this.maxLevel = maxLevel;
    }

    @Override
    public int method_8183() {
        return maxLevel;
    }

    @Override
    public int method_8182(int level) {
        return 1 + (level - 1) * 10;
    }

    @Override
    public int method_20742(int level) {
        return method_8182(level) + 50;
    }

    /**
     * Par défaut, les enchantements UltraEnchants sont compatibles entre eux,
     * sauf si on surcharge cette méthode.
     */
    @Override
    protected boolean method_8180(class_1887 other) {
        if (other instanceof BaseEnchantment) return true;
        return super.method_8180(other);
    }

    // Utilitaire : récupère le niveau sur un stack
    public int getLevel(class_1799 stack) {
        return net.minecraft.class_1890.method_8225(this, stack);
    }
}
