package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class ReflectEnchantment extends BaseEnchantment {
    public ReflectEnchantment() { super(class_1888.field_9088, class_1886.field_9071, 3, class_1304.field_6174); }
}
