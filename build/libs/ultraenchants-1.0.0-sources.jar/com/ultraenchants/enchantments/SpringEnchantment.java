package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class SpringEnchantment extends BaseEnchantment {
    public SpringEnchantment() { super(class_1888.field_9090, class_1886.field_9079, 4, class_1304.field_6166); }
}
