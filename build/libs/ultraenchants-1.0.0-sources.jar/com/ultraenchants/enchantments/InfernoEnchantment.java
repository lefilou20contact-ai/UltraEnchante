package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class InfernoEnchantment extends BaseEnchantment {
    public InfernoEnchantment() { super(class_1888.field_9090, class_1886.field_9074, 4, class_1304.field_6173); }
    @Override
    protected boolean method_8180(net.minecraft.class_1887 other) {
        if (other instanceof net.minecraft.class_1892) return false;
        return super.method_8180(other);
    }
}
