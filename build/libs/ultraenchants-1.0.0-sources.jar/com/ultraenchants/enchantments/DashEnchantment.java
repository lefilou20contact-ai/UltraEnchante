package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class DashEnchantment extends BaseEnchantment {
    public DashEnchantment() { super(class_1888.field_9088, class_1886.field_9079, 3, class_1304.field_6166); }
}
