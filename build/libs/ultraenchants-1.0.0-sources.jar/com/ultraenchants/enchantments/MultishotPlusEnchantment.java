package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class MultishotPlusEnchantment extends BaseEnchantment {
    public MultishotPlusEnchantment() { super(class_1888.field_9088, class_1886.field_9081, 3, class_1304.field_6173); }
    @Override
    protected boolean method_8180(net.minecraft.class_1887 other) {
        if (other instanceof net.minecraft.class_1898) return false;
        return super.method_8180(other);
    }
}
