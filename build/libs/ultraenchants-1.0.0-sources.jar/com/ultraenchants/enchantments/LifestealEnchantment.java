package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class LifestealEnchantment extends BaseEnchantment {
    public LifestealEnchantment() { super(class_1888.field_9088, class_1886.field_9074, 5, class_1304.field_6173); }
    @Override public boolean method_8193() { return false; }
}
