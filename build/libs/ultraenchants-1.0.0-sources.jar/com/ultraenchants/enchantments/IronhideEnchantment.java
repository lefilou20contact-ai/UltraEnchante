package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class IronhideEnchantment extends BaseEnchantment {
    public IronhideEnchantment() { super(class_1888.field_9088, class_1886.field_9071, 4, class_1304.field_6174); }
}
