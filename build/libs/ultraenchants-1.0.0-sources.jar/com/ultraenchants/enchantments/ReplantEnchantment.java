package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class ReplantEnchantment extends BaseEnchantment {
    public ReplantEnchantment() { super(class_1888.field_9087, class_1886.field_9069, 1, class_1304.field_6173); }
}
