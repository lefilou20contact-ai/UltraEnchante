package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class ExplosiveArrowEnchantment extends BaseEnchantment {
    public ExplosiveArrowEnchantment() { super(class_1888.field_9091, class_1886.field_9070, 3, class_1304.field_6173); }
    @Override public boolean method_8193() { return true; }
}
