package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class WitherArrowEnchantment extends BaseEnchantment {
    public WitherArrowEnchantment() { super(class_1888.field_9088, class_1886.field_9070, 2, class_1304.field_6173); }
}
