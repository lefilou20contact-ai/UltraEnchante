package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class SpeedBoostEnchantment extends BaseEnchantment {
    public SpeedBoostEnchantment() { super(class_1888.field_9090, class_1886.field_9079, 3, class_1304.field_6166); }
}
