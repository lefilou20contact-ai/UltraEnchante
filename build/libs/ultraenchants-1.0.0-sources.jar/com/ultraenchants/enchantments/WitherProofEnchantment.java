package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class WitherProofEnchantment extends BaseEnchantment {
    public WitherProofEnchantment() { super(class_1888.field_9091, class_1886.field_9071, 1, class_1304.field_6174); }
    @Override public boolean method_8193() { return true; }
}
