package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class CurseDecayEnchantment extends BaseEnchantment {
    public CurseDecayEnchantment() {
        super(class_1888.field_9091, class_1886.field_9082, 1,
                class_1304.field_6173, class_1304.field_6171,
                class_1304.field_6169, class_1304.field_6174,
                class_1304.field_6172, class_1304.field_6166);
    }
    @Override public boolean method_8195() { return true; }
    @Override public boolean method_8193() { return false; }
}
