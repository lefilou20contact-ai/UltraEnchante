package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class GuardianEnchantment extends BaseEnchantment {
    public GuardianEnchantment() {
        super(class_1888.field_9088, class_1886.field_9068, 3,
                class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6169);
    }
}
