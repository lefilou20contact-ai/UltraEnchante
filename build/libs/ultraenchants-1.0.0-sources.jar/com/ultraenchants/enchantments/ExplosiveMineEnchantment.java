package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class ExplosiveMineEnchantment extends BaseEnchantment {
    public ExplosiveMineEnchantment() { super(class_1888.field_9091, class_1886.field_9069, 3, class_1304.field_6173); }
    @Override public boolean method_8193() { return true; }
    @Override
    protected boolean method_8180(net.minecraft.class_1887 other) {
        if (other instanceof VeinminerEnchantment) return false;
        if (other instanceof net.minecraft.class_1909) return false;
        return super.method_8180(other);
    }
}
