package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class ExecuteEnchantment extends BaseEnchantment {
    public ExecuteEnchantment() { super(class_1888.field_9091, class_1886.field_9074, 4, class_1304.field_6173); }
    @Override public boolean method_8193() { return true; }
}
