package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class HomingEnchantment extends BaseEnchantment {
    public HomingEnchantment() { super(class_1888.field_9091, class_1886.field_9070, 2, class_1304.field_6173); }
    @Override public boolean method_8193() { return true; }
}
