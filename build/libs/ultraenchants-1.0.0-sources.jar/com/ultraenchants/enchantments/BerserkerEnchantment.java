package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class BerserkerEnchantment extends BaseEnchantment {
    public BerserkerEnchantment() { super(class_1888.field_9088, class_1886.field_9074, 3, class_1304.field_6173); }
}
