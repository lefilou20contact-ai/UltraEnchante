package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class ThornsPlusEnchantment extends BaseEnchantment {
    public ThornsPlusEnchantment() {
        super(class_1888.field_9090, class_1886.field_9071, 5,
                class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6169);
    }
    @Override
    protected boolean method_8180(net.minecraft.class_1887 other) {
        if (other instanceof net.minecraft.class_1906) return false;
        return super.method_8180(other);
    }
}
