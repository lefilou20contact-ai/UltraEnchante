package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class LavaWalkerEnchantment extends BaseEnchantment {
    public LavaWalkerEnchantment() { super(class_1888.field_9091, class_1886.field_9079, 2, class_1304.field_6166); }
    @Override public boolean method_8193() { return true; }
    @Override
    protected boolean method_8180(net.minecraft.class_1887 other) {
        if (other instanceof net.minecraft.class_1894) return false;
        return super.method_8180(other);
    }
}
