package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class AntiGravityEnchantment extends BaseEnchantment {
    public AntiGravityEnchantment() { super(class_1888.field_9088, class_1886.field_9079, 2, class_1304.field_6166); }
}
