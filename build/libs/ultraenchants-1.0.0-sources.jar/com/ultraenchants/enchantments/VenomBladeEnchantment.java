package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class VenomBladeEnchantment extends BaseEnchantment {
    public VenomBladeEnchantment() { super(class_1888.field_9090, class_1886.field_9074, 3, class_1304.field_6173); }
}
