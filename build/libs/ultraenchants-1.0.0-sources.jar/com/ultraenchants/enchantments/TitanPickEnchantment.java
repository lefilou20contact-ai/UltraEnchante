package com.ultraenchants.enchantments;
import net.minecraft.class_1304;
import net.minecraft.class_1886;
public class TitanPickEnchantment extends BaseEnchantment {
    public TitanPickEnchantment() { super(class_1888.field_9088, class_1886.field_9069, 5, class_1304.field_6173); }
    @Override
    protected boolean method_8180(net.minecraft.class_1887 other) {
        if (other instanceof net.minecraft.class_1884) return false;
        return super.method_8180(other);
    }
}
