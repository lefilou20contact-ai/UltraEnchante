package com.ultraenchants.init;

import com.ultraenchants.UltraEnchantsMain;
import com.ultraenchants.enchantments.*;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import net.minecraft.item.*;
import java.util.List;

public class ModEnchantments {

    // ═══════════════════════════════════════════
    //  ÉPÉE
    // ═══════════════════════════════════════════
    public static final class_1887 LIFESTEAL        = new LifestealEnchantment();
    public static final class_1887 THUNDERSTRIKE    = new ThunderstrikeEnchantment();
    public static final class_1887 SOULREND         = new SoulrendEnchantment();
    public static final class_1887 BERSERKER        = new BerserkerEnchantment();
    public static final class_1887 VENOM_BLADE      = new VenomBladeEnchantment();
    public static final class_1887 EXECUTE          = new ExecuteEnchantment();
    public static final class_1887 VAMPIRISM        = new VampirismEnchantment();
    public static final class_1887 BLEED            = new BleedEnchantment();
    public static final class_1887 GRAVITON         = new GravitonEnchantment();
    public static final class_1887 INFERNO          = new InfernoEnchantment();

    // ═══════════════════════════════════════════
    //  ARC / ARBALÈTE
    // ═══════════════════════════════════════════
    public static final class_1887 SNIPER           = new SniperEnchantment();
    public static final class_1887 EXPLOSIVE_ARROW  = new ExplosiveArrowEnchantment();
    public static final class_1887 CHAIN_LIGHTNING  = new ChainLightningEnchantment();
    public static final class_1887 HOMING           = new HomingEnchantment();
    public static final class_1887 WITHER_ARROW     = new WitherArrowEnchantment();
    public static final class_1887 ICESHOT          = new IceshotEnchantment();
    public static final class_1887 MULTISHOT_PLUS   = new MultishotPlusEnchantment();
    public static final class_1887 BOUNCE           = new BounceEnchantment();

    // ═══════════════════════════════════════════
    //  ARMURE
    // ═══════════════════════════════════════════
    public static final class_1887 THORNS_PLUS      = new ThornsPlusEnchantment();
    public static final class_1887 GUARDIAN         = new GuardianEnchantment();
    public static final class_1887 ANGEL            = new AngelEnchantment();
    public static final class_1887 MAGNET           = new MagnetEnchantment();
    public static final class_1887 SPEED_BOOST      = new SpeedBoostEnchantment();
    public static final class_1887 IRONHIDE         = new IronhideEnchantment();
    public static final class_1887 REFLECT          = new ReflectEnchantment();
    public static final class_1887 WITHER_PROOF     = new WitherProofEnchantment();
    public static final class_1887 UNDYING_PLUS     = new UndyingPlusEnchantment();

    // ═══════════════════════════════════════════
    //  PIOCHE / OUTILS
    // ═══════════════════════════════════════════
    public static final class_1887 VEINMINER        = new VeinminerEnchantment();
    public static final class_1887 SMELTING         = new SmeltingEnchantment();
    public static final class_1887 MAGNETIC_PICK    = new MagneticPickEnchantment();
    public static final class_1887 EXPLOSIVE_MINE   = new ExplosiveMineEnchantment();
    public static final class_1887 LUMBER           = new LumberEnchantment();
    public static final class_1887 REPLANT          = new ReplantEnchantment();
    public static final class_1887 TITAN_PICK       = new TitanPickEnchantment();

    // ═══════════════════════════════════════════
    //  BOTTES
    // ═══════════════════════════════════════════
    public static final class_1887 SPRING           = new SpringEnchantment();
    public static final class_1887 LAVA_WALKER      = new LavaWalkerEnchantment();
    public static final class_1887 DASH             = new DashEnchantment();
    public static final class_1887 ANTI_GRAVITY     = new AntiGravityEnchantment();

    // ═══════════════════════════════════════════
    //  TOUT ITEM
    // ═══════════════════════════════════════════
    public static final class_1887 CURSE_DECAY      = new CurseDecayEnchantment();
    public static final class_1887 SOULBOUND        = new SoulboundEnchantment();

    public static void registerAll() {
        // Épée
        register("lifesteal",        LIFESTEAL);
        register("thunderstrike",    THUNDERSTRIKE);
        register("soulrend",         SOULREND);
        register("berserker",        BERSERKER);
        register("venom_blade",      VENOM_BLADE);
        register("execute",          EXECUTE);
        register("vampirism",        VAMPIRISM);
        register("bleed",            BLEED);
        register("graviton",         GRAVITON);
        register("inferno",          INFERNO);

        // Arc / Arbalète
        register("sniper",           SNIPER);
        register("explosive_arrow",  EXPLOSIVE_ARROW);
        register("chain_lightning",  CHAIN_LIGHTNING);
        register("homing",           HOMING);
        register("wither_arrow",     WITHER_ARROW);
        register("iceshot",          ICESHOT);
        register("multishot_plus",   MULTISHOT_PLUS);
        register("bounce",           BOUNCE);

        // Armure
        register("thorns_plus",      THORNS_PLUS);
        register("guardian",         GUARDIAN);
        register("angel",            ANGEL);
        register("magnet",           MAGNET);
        register("speed_boost",      SPEED_BOOST);
        register("ironhide",         IRONHIDE);
        register("reflect",          REFLECT);
        register("wither_proof",     WITHER_PROOF);
        register("undying_plus",     UNDYING_PLUS);

        // Outils
        register("veinminer",        VEINMINER);
        register("smelting",         SMELTING);
        register("magnetic_pick",    MAGNETIC_PICK);
        register("explosive_mine",   EXPLOSIVE_MINE);
        register("lumber",           LUMBER);
        register("replant",          REPLANT);
        register("titan_pick",       TITAN_PICK);

        // Bottes
        register("spring",           SPRING);
        register("lava_walker",      LAVA_WALKER);
        register("dash",             DASH);
        register("anti_gravity",     ANTI_GRAVITY);

        // Spéciaux
        register("curse_decay",      CURSE_DECAY);
        register("soulbound",        SOULBOUND);
    }

    private static void register(String name, class_1887 enchantment) {
        class_2378.method_10230(class_7923.field_41176, new class_2960(UltraEnchantsMain.MOD_ID, name), enchantment);
    }

    // ═══════════════════════════════════════════
    //  EVENTS FABRIC — logique des enchantements
    // ═══════════════════════════════════════════
    public static void registerEvents() {

        // --- Attaque d'entité (épée) ---
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            class_1799 weapon = player.method_6047();
            if (!(entity instanceof class_1309 target)) return class_1269.field_5811;

            // LIFESTEAL : vol de vie
            // NOTE : voir LifestealEnchantment pour l'implémentation via Mixin

            // THUNDERSTRIKE : frappe de foudre (niveau 1-3, chance croissante)
            int thunderLvl = getEnchantLevel(weapon, THUNDERSTRIKE);
            if (thunderLvl > 0 && world instanceof class_3218 sw) {
                float chance = 0.10f * thunderLvl;
                if (world.method_8409().method_43057() < chance) {
                    class_1538 lightning = class_1299.field_6112.method_5883(world);
                    if (lightning != null) {
                        lightning.method_24203(entity.method_23317(), entity.method_23318(), entity.method_23321());
                        lightning.method_29498(false);
                        sw.method_8649(lightning);
                    }
                }
            }

            // GRAVITON : repousse l'ennemi
            int gravitonLvl = getEnchantLevel(weapon, GRAVITON);
            if (gravitonLvl > 0) {
                double force = 1.5 * gravitonLvl;
                entity.method_18799(entity.method_18798().method_1031(0, 0.4 * gravitonLvl, 0)
                        .method_1019(player.method_5720().method_1021(force * 0.3)));
            }

            // BLEED : applique slowness + saignement (particules + dégâts sur temps)
            int bleedLvl = getEnchantLevel(weapon, BLEED);
            if (bleedLvl > 0) {
                target.method_6092(new class_1293(class_1294.field_5909, 60 * bleedLvl, bleedLvl - 1));
                if (world instanceof class_3218 sw2) {
                    for (int i = 0; i < 8; i++) {
                        sw2.method_14199(class_2398.field_11209,
                                target.method_23317(), target.method_23318() + 1, target.method_23321(),
                                3, 0.3, 0.3, 0.3, 0.1);
                    }
                }
            }

            // INFERNO : met le feu (durée selon niveau)
            int infernoLvl = getEnchantLevel(weapon, INFERNO);
            if (infernoLvl > 0) {
                entity.method_5639(4 * infernoLvl);
            }

            // VENOM_BLADE : poison puissant
            int venomLvl = getEnchantLevel(weapon, VENOM_BLADE);
            if (venomLvl > 0) {
                target.method_6092(new class_1293(class_1294.field_5899, 100 * venomLvl, venomLvl));
            }

            // EXECUTE : bonus dégâts si cible < 25% vie
            // (géré via Mixin LivingEntityMixin)

            return class_1269.field_5811;
        });

        // --- Cassage de bloc (outils) ---
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            class_1799 tool = player.method_6047();

            // MAGNETIC_PICK : attire les drops vers le joueur
            int magnetLvl = getEnchantLevel(tool, MAGNETIC_PICK);
            if (magnetLvl > 0 && world instanceof class_3218 sw) {
                double radius = 4.0 * magnetLvl;
                List<net.minecraft.class_1542> items = world.method_18023(
                        class_1299.field_6052,
                        new class_238(pos).method_1014(radius),
                        e -> true
                );
                for (net.minecraft.class_1542 item : items) {
                    item.method_23327(player.method_23317(), player.method_23318(), player.method_23321());
                }
            }

            // REPLANT : replante automatiquement les cultures
            int replantLvl = getEnchantLevel(tool, REPLANT);
            if (replantLvl > 0) {
                // La logique complète est dans ReplantEnchantment
            }
        });
    }

    // Utilitaire pour récupérer le niveau d'enchantement sur un ItemStack
    public static int getEnchantLevel(class_1799 stack, class_1887 enchantment) {
        return net.minecraft.class_1890.method_8225(enchantment, stack);
    }

    // Version via ItemStack directement
    public static int getLevel(class_1799 stack, class_1887 ench) {
        return net.minecraft.class_1890.method_8225(ench, stack);
    }
}
