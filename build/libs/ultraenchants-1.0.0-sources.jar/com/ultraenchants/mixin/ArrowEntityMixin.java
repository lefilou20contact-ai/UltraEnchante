package com.ultraenchants.mixin;

import com.ultraenchants.init.ModEnchantments;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1657;
import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1667.class)
public abstract class ArrowEntityMixin {

    /**
     * Gestion des effets à l'impact d'une flèche.
     * - EXPLOSIVE_ARROW : explosion
     * - WITHER_ARROW : effet wither
     * - ICESHOT : gel de la cible
     * - CHAIN_LIGHTNING : foudre en chaîne
     * - SNIPER : dégâts de distance
     */
    @Inject(method = "onEntityHit", at = @At("TAIL"))
    private void onEntityHit(class_3966 hitResult, CallbackInfo ci) {
        class_1667 arrow = (class_1667) (Object) this;
        if (!(arrow.method_24921() instanceof class_1657 shooter)) return;
        if (!(hitResult.method_17782() instanceof class_1309 target)) return;

        class_1799 bow = shooter.method_6047();
        // Essaie aussi l'offhand (arbalète)
        if (!bow.method_7909().toString().contains("bow") && !bow.method_7909().toString().contains("crossbow")) {
            bow = shooter.method_6079();
        }

        // === EXPLOSIVE_ARROW ===
        int explosiveLvl = class_1890.method_8225(ModEnchantments.EXPLOSIVE_ARROW, bow);
        if (explosiveLvl > 0) {
            float radius = 1.5f + 0.5f * explosiveLvl;
            arrow.method_37908().method_8537(
                    arrow, target.method_23317(), target.method_23318(), target.method_23321(),
                    radius, false, net.minecraft.class_1937.class_7867.field_40890
            );
        }

        // === WITHER_ARROW ===
        int witherLvl = class_1890.method_8225(ModEnchantments.WITHER_ARROW, bow);
        if (witherLvl > 0) {
            target.method_6092(new class_1293(
                    class_1294.field_5920, 100 * witherLvl, 1));
        }

        // === ICESHOT ===
        int iceLvl = class_1890.method_8225(ModEnchantments.ICESHOT, bow);
        if (iceLvl > 0) {
            target.method_6092(new class_1293(
                    class_1294.field_5909, 60 * iceLvl, 2 + iceLvl));
            target.method_6092(new class_1293(
                    class_1294.field_5901, 60 * iceLvl, 0));
            if (arrow.method_37908() instanceof class_3218 sw) {
                sw.method_14199(class_2398.field_28013,
                        target.method_23317(), target.method_23318() + 1, target.method_23321(),
                        20, 0.5, 0.5, 0.5, 0.1);
            }
        }

        // === CHAIN_LIGHTNING (arc) ===
        int chainLvl = class_1890.method_8225(ModEnchantments.CHAIN_LIGHTNING, bow);
        if (chainLvl > 0 && arrow.method_37908() instanceof class_3218 sw) {
            var nearby = arrow.method_37908().method_8390(
                    class_1309.class,
                    target.method_5829().method_1014(6 + 2.0 * chainLvl),
                    e -> e != target && e != shooter
            );
            int hit = 0;
            for (class_1309 e : nearby) {
                if (hit >= 3 * chainLvl) break;
                class_1538 bolt = class_1299.field_6112.method_5883(arrow.method_37908());
                if (bolt != null) {
                    bolt.method_24203(e.method_23317(), e.method_23318(), e.method_23321());
                    bolt.method_29498(true); // visuellement
                    sw.method_8649(bolt);
                    e.method_5643(arrow.method_37908().method_48963().method_48830(), 4 * chainLvl);
                    hit++;
                }
            }
        }

        // === SNIPER : bonus dégâts selon distance ===
        int sniperLvl = class_1890.method_8225(ModEnchantments.SNIPER, bow);
        if (sniperLvl > 0) {
            double distance = shooter.method_19538().method_1022(target.method_19538());
            if (distance > 10) {
                float bonusDmg = (float)(distance * 0.05f * sniperLvl);
                target.method_5643(arrow.method_37908().method_48963().method_48830(), bonusDmg);
                if (arrow.method_37908() instanceof class_3218 sw) {
                    sw.method_14199(class_2398.field_11205,
                            target.method_23317(), target.method_23318() + 1, target.method_23321(),
                            8, 0.3, 0.3, 0.3, 0.3);
                }
            }
        }
    }

    /**
     * HOMING : la flèche suit la cible la plus proche
     */
    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        class_1667 arrow = (class_1667) (Object) this;
        if (arrow.method_37908().method_8608()) return;
        if (!(arrow.method_24921() instanceof class_1657 shooter)) return;

        class_1799 bow = shooter.method_6047();
        int homingLvl = class_1890.method_8225(ModEnchantments.HOMING, bow);
        if (homingLvl == 0) return;

        // Trouve la cible la plus proche dans un rayon
        double searchRadius = 8.0 * homingLvl;
        var nearest = arrow.method_37908().method_8390(
                class_1309.class,
                arrow.method_5829().method_1014(searchRadius),
                e -> e != shooter && e.method_5805()
        ).stream()
                .min((a, b) -> Double.compare(
                        a.method_5858(arrow),
                        b.method_5858(arrow)
                ));

        nearest.ifPresent(target -> {
            var dir = target.method_19538().method_1031(0, target.method_17682() / 2, 0)
                    .method_1020(arrow.method_19538()).method_1029();
            var vel = arrow.method_18798();
            var newVel = vel.method_1019(dir.method_1021(0.05 * homingLvl)).method_1029()
                    .method_1021(vel.method_1033());
            arrow.method_18799(newVel);
        });
    }
}
