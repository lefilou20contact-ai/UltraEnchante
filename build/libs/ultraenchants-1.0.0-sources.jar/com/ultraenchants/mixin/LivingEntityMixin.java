package com.ultraenchants.mixin;

import com.ultraenchants.init.ModEnchantments;
import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    /**
     * Modifie les dégâts selon les enchantements d'épée actifs.
     * - LIFESTEAL : vol de vie
     * - BERSERKER : bonus si PV bas
     * - EXECUTE : bonus si cible < 25% vie
     * - GUARDIAN : réduction des dégâts
     * - UNDYING_PLUS : survie à mort
     */
    @ModifyVariable(method = "damage", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private float modifyIncomingDamage(float amount, class_1282 source) {
        class_1309 self = (class_1309) (Object) this;

        // === GUARDIAN : réduit les dégâts entrants ===
        for (class_1799 armorPiece : self.method_5661()) {
            int guardianLvl = class_1890.method_8225(ModEnchantments.GUARDIAN, armorPiece);
            if (guardianLvl > 0) {
                amount *= (1.0f - 0.05f * guardianLvl);
            }
        }

        // === REFLECT : chance de renvoyer la flèche ===
        if (source.method_5529() instanceof class_1309 attacker) {
            for (class_1799 armorPiece : self.method_5661()) {
                int reflectLvl = class_1890.method_8225(ModEnchantments.REFLECT, armorPiece);
                if (reflectLvl > 0) {
                    float reflectChance = 0.15f * reflectLvl;
                    if (self.method_37908().method_8409().method_43057() < reflectChance) {
                        attacker.method_5643(self.method_37908().method_48963().method_48830(), amount * 0.5f);
                        amount = 0;
                    }
                }
            }
        }

        // === IRONHIDE : résistance physique via armure poitrine ===
        class_1799 chest = self.method_6118(net.minecraft.class_1304.field_6174);
        int ironhideLvl = class_1890.method_8225(ModEnchantments.IRONHIDE, chest);
        if (ironhideLvl > 0 && source.method_5529() instanceof class_1309) {
            amount *= (1.0f - 0.08f * ironhideLvl);
        }

        return amount;
    }

    /**
     * Après avoir infligé des dégâts — logique de l'attaquant.
     */
    @Inject(method = "damage", at = @At("TAIL"))
    private void onDamage(class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue()) return;
        class_1309 self = (class_1309) (Object) this;
        if (!(source.method_5529() instanceof class_1657 attacker)) return;

        class_1799 weapon = attacker.method_6047();

        // === LIFESTEAL ===
        int lifestealLvl = class_1890.method_8225(ModEnchantments.LIFESTEAL, weapon);
        if (lifestealLvl > 0) {
            float heal = amount * 0.05f * lifestealLvl;
            attacker.method_6025(heal);
            if (attacker.method_37908() instanceof class_3218 sw) {
                sw.method_14199(class_2398.field_11201,
                        attacker.method_23317(), attacker.method_23318() + 1.5, attacker.method_23321(),
                        3, 0.5, 0.5, 0.5, 0.1);
            }
        }

        // === VAMPIRISM : regen au combat ===
        int vampLvl = class_1890.method_8225(ModEnchantments.VAMPIRISM, weapon);
        if (vampLvl > 0) {
            attacker.method_6092(new class_1293(
                    class_1294.field_5924,
                    60 + 40 * vampLvl,
                    vampLvl - 1,
                    true, false
            ));
        }

        // === BERSERKER : plus de dégâts quand PV bas ===
        int berserkerLvl = class_1890.method_8225(ModEnchantments.BERSERKER, weapon);
        if (berserkerLvl > 0) {
            float healthPercent = attacker.method_6032() / attacker.method_6063();
            if (healthPercent < 0.5f) {
                float bonus = 1.0f + (0.5f - healthPercent) * 0.4f * berserkerLvl;
                self.method_5643(attacker.method_37908().method_48963().method_48830(), amount * (bonus - 1));
            }
        }

        // === EXECUTE : bonus dégâts < 25% vie cible ===
        int executeLvl = class_1890.method_8225(ModEnchantments.EXECUTE, weapon);
        if (executeLvl > 0) {
            float targetHealth = self.method_6032() / self.method_6063();
            if (targetHealth < 0.25f) {
                float bonusDmg = amount * 0.5f * executeLvl;
                self.method_5643(attacker.method_37908().method_48963().method_48830(), bonusDmg);
                if (attacker.method_37908() instanceof class_3218 sw) {
                    sw.method_14199(class_2398.field_11205,
                            self.method_23317(), self.method_23318() + 1, self.method_23321(),
                            10, 0.5, 0.5, 0.5, 0.5);
                }
            }
        }

        // === SOULREND : dégâts bonus vs undead & joueurs ===
        int soulrendLvl = class_1890.method_8225(ModEnchantments.SOULREND, weapon);
        if (soulrendLvl > 0) {
            boolean isUndead = self.method_5864().method_20210(net.minecraft.class_3483.field_46232);
            boolean isPlayer = self instanceof class_1657;
            if (isUndead || isPlayer) {
                self.method_5643(attacker.method_37908().method_48963().method_48830(), 1.5f * soulrendLvl);
            }
        }

        // === CHAIN_LIGHTNING : arc sur les mobs proches ===
        int chainLvl = class_1890.method_8225(ModEnchantments.CHAIN_LIGHTNING, weapon);
        if (chainLvl > 0 && attacker.method_37908() instanceof class_3218 sw) {
            int chainCount = 3 * chainLvl;
            var nearby = attacker.method_37908().method_8390(
                    class_1309.class,
                    new class_238(self.method_19538(), self.method_19538()).method_1014(8),
                    e -> e != self && e != attacker
            );
            int hit = 0;
            for (class_1309 nearby_entity : nearby) {
                if (hit >= chainCount) break;
                nearby_entity.method_5643(attacker.method_37908().method_48963().method_48830(), 3 * chainLvl);
                sw.method_14199(class_2398.field_29644,
                        nearby_entity.method_23317(), nearby_entity.method_23318() + 1, nearby_entity.method_23321(),
                        15, 0.3, 0.5, 0.3, 0.2);
                hit++;
            }
        }
    }

    /**
     * WITHER_PROOF : immunité à l'effet wither
     */
    @Inject(method = "canHaveStatusEffect", at = @At("RETURN"), cancellable = true)
    private void cancelWitherEffect(class_1293 effect, CallbackInfoReturnable<Boolean> cir) {
        class_1309 self = (class_1309) (Object) this;
        if (effect.method_5579() == class_1294.field_5920) {
            for (class_1799 armor : self.method_5661()) {
                if (class_1890.method_8225(ModEnchantments.WITHER_PROOF, armor) > 0) {
                    cir.setReturnValue(false);
                    return;
                }
            }
        }
    }

    /**
     * UNDYING_PLUS : survie à la mort
     */
    @Inject(method = "tryUseTotem", at = @At("HEAD"), cancellable = true)
    private void undyingPlus(class_1282 source, CallbackInfoReturnable<Boolean> cir) {
        class_1309 self = (class_1309) (Object) this;
        class_1799 chest = self.method_6118(net.minecraft.class_1304.field_6174);
        int undyingLvl = class_1890.method_8225(ModEnchantments.UNDYING_PLUS, chest);

        if (undyingLvl > 0) {
            float healAmount = 2.0f + 4.0f * undyingLvl;
            self.method_6033(healAmount);
            self.method_6012();
            self.method_6092(new class_1293(class_1294.field_5924, 900, undyingLvl));
            self.method_6092(new class_1293(class_1294.field_5898, 100, undyingLvl));
            if (undyingLvl >= 3) {
                self.method_6092(new class_1293(class_1294.field_5918, 200, 0));
                self.method_6092(new class_1293(class_1294.field_5907, 200, 1));
            }
            cir.setReturnValue(true);
        }
    }
}
