package com.ultraenchants.mixin;

import com.ultraenchants.init.ModEnchantments;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1303;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_238;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin {

    private int dashCooldown = 0;

    /**
     * Tick côté serveur : gère les enchantements passifs (Magnet, Speed Boost, Guardian, Spring, Anti Gravity).
     */
    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        if (player.method_37908().method_8608()) return;

        // Cooldown du dash
        if (dashCooldown > 0) dashCooldown--;

        // === MAGNET (armure poitrine) ===
        class_1799 chest = player.method_6118(net.minecraft.class_1304.field_6174);
        int magnetLvl = class_1890.method_8225(ModEnchantments.MAGNET, chest);
        if (magnetLvl > 0) {
            double radius = 4.0 + 2.0 * magnetLvl;
            class_238 area = new class_238(player.method_24515()).method_1014(radius);

            // Attire les items
            List<class_1542> items = player.method_37908().method_8390(class_1542.class, area, e -> true);
            for (class_1542 item : items) {
                item.method_23327(player.method_23317(), player.method_23318(), player.method_23321());
            }

            // Attire l'XP
            List<class_1303> orbs = player.method_37908().method_8390(class_1303.class, area, e -> true);
            for (class_1303 orb : orbs) {
                orb.method_23327(player.method_23317(), player.method_23318(), player.method_23321());
            }
        }

        // === SPEED_BOOST (bottes) ===
        class_1799 boots = player.method_6118(net.minecraft.class_1304.field_6166);
        int speedLvl = class_1890.method_8225(ModEnchantments.SPEED_BOOST, boots);
        if (speedLvl > 0) {
            // Applique Speed en continu (court durée pour refresh chaque tick)
            if (!player.method_6059(class_1294.field_5904) ||
                    player.method_6112(class_1294.field_5904).method_5578() < speedLvl - 1) {
                player.method_6092(new class_1293(
                        class_1294.field_5904, 40, speedLvl - 1, true, false, false));
            }
        }

        // === SPRING (bottes) : Jump Boost ===
        int springLvl = class_1890.method_8225(ModEnchantments.SPRING, boots);
        if (springLvl > 0) {
            if (!player.method_6059(class_1294.field_5913) ||
                    player.method_6112(class_1294.field_5913).method_5578() < springLvl - 1) {
                player.method_6092(new class_1293(
                        class_1294.field_5913, 40, springLvl - 1, true, false, false));
            }
        }

        // === ANGEL (poitrine) : lévitation légère ===
        int angelLvl = class_1890.method_8225(ModEnchantments.ANGEL, chest);
        if (angelLvl > 0 && player.method_5715() && player.field_6017 > 0) {
            // Ralentit la chute via slow fall
            if (!player.method_6059(class_1294.field_5906)) {
                player.method_6092(new class_1293(
                        class_1294.field_5906, 40, angelLvl - 1, true, false, false));
            }
        }

        // === IRONHIDE (poitrine) : Résistance ===
        int ironhideLvl = class_1890.method_8225(ModEnchantments.IRONHIDE, chest);
        if (ironhideLvl > 0) {
            if (!player.method_6059(class_1294.field_5907) ||
                    player.method_6112(class_1294.field_5907).method_5578() < ironhideLvl - 1) {
                player.method_6092(new class_1293(
                        class_1294.field_5907, 40, ironhideLvl - 1, true, false, false));
            }
        }
    }

    /**
     * ANTI_GRAVITY + SPRING : annule les dégâts de chute
     */
    @Inject(method = "handleFallDamage", at = @At("HEAD"), cancellable = true)
    private void cancelFallDamage(float fallDistance, float damageMultiplier,
                                   net.minecraft.class_1282 damageSource, CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        class_1799 boots = player.method_6118(net.minecraft.class_1304.field_6166);

        // Anti Gravity : annule complètement
        int antiGravityLvl = class_1890.method_8225(ModEnchantments.ANTI_GRAVITY, boots);
        if (antiGravityLvl > 0) {
            ci.cancel();
            return;
        }

        // Spring : réduit de 25% par niveau
        int springLvl = class_1890.method_8225(ModEnchantments.SPRING, boots);
        if (springLvl > 0) {
            float reduced = fallDistance * (1.0f - 0.25f * springLvl);
            if (reduced <= 3.0f) {
                ci.cancel();
            }
        }
    }

    /**
     * SOULBOUND : garde les items à la mort
     */
    @Inject(method = "dropInventory", at = @At("HEAD"), cancellable = true)
    private void keepSoulboundItems(CallbackInfo ci) {
        class_1657 player = (class_1657) (Object) this;
        // Parcourt l'inventaire et marque les items Soulbound comme "keep"
        for (int i = 0; i < player.method_31548().method_5439(); i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (!stack.method_7960() && class_1890.method_8225(ModEnchantments.SOULBOUND, stack) > 0) {
                // L'item reste — on remet en place après le drop via gamerule keepInventory pour cet item
                // Implementation complète nécessite un Mixin sur PlayerInventory.dropAll()
                // Ici on log pour montrer la logique
                org.slf4j.LoggerFactory.getLogger("UltraEnchants").info("[UltraEnchants] Soulbound: {} conservé", stack.method_7964().getString());
            }
        }
    }
}
