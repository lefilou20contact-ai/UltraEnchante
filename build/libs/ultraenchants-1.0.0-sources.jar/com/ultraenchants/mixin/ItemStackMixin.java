package com.ultraenchants.mixin;

import com.ultraenchants.init.ModEnchantments;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3956;
import net.minecraft.class_7923;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {

    /**
     * VEINMINER + SMELTING + TITAN_PICK + LUMBER : logique après le minage
     */
    @Inject(method = "postMine", at = @At("TAIL"))
    private void onPostMine(class_1937 world, class_2680 state, class_2338 pos,
                             class_1657 miner, CallbackInfoReturnable<Boolean> cir) {
        if (world.method_8608() || !(miner instanceof class_3222 player)) return;
        class_1799 tool = player.method_6047();

        // === VEINMINER ===
        int veinLvl = class_1890.method_8225(ModEnchantments.VEINMINER, tool);
        if (veinLvl > 0) {
            int maxBlocks = 8 * veinLvl;
            Set<class_2338> visited = new HashSet<>();
            Queue<class_2338> queue = new LinkedList<>();
            queue.add(pos);
            int count = 0;

            while (!queue.isEmpty() && count < maxBlocks) {
                class_2338 current = queue.poll();
                if (visited.contains(current)) continue;
                visited.add(current);

                for (class_2338 neighbor : getNeighbors(current)) {
                    if (!visited.contains(neighbor)) {
                        class_2680 neighborState = world.method_8320(neighbor);
                        if (neighborState.method_26204() == state.method_26204()) {
                            class_2248.method_9511(neighborState, (class_3218) world, neighbor, null, player, tool);
                            world.method_8650(neighbor, false);
                            queue.add(neighbor);
                            count++;
                        }
                    }
                }
            }
        }

        // === LUMBER : coupe tout l'arbre ===
        int lumberLvl = class_1890.method_8225(ModEnchantments.LUMBER, tool);
        if (lumberLvl > 0) {
            String blockName = class_7923.field_41175.method_10221(state.method_26204()).method_12832();
            if (blockName.contains("_log") || blockName.contains("_stem")) {
                int maxLogs = 32 * lumberLvl;
                Set<class_2338> visited = new HashSet<>();
                Queue<class_2338> queue = new LinkedList<>();
                queue.add(pos);
                int count = 0;

                while (!queue.isEmpty() && count < maxLogs) {
                    class_2338 current = queue.poll();
                    if (visited.contains(current)) continue;
                    visited.add(current);

                    // Cherche en haut et côtés
                    for (class_2338 neighbor : getNeighborsAndUp(current)) {
                        if (!visited.contains(neighbor)) {
                            class_2680 ns = world.method_8320(neighbor);
                            String neighborName = class_7923.field_41175.method_10221(ns.method_26204()).method_12832();
                            if (neighborName.contains("_log") || neighborName.contains("_stem")
                                    || ns.method_26204() instanceof class_2397) {
                                class_2248.method_9511(ns, (class_3218) world, neighbor, null, player, tool);
                                world.method_8650(neighbor, false);
                                queue.add(neighbor);
                                count++;
                            }
                        }
                    }
                }
            }
        }

        // === SMELTING : fond les drops automatiquement ===
        int smeltLvl = class_1890.method_8225(ModEnchantments.SMELTING, tool);
        if (smeltLvl > 0 && world instanceof class_3218 sw) {
            // Les drops ont déjà été placés par minecraft — on cherche les ItemEntity proches
            // et on essaie de les fondre selon les recettes de furnace
            var drops = world.method_8390(
                    net.minecraft.class_1542.class,
                    new net.minecraft.class_238(pos).method_1014(2),
                    e -> true
            );
            for (var drop : drops) {
                class_1799 dropStack = drop.method_6983();
                // Cherche la recette de fonte
                sw.method_8433()
                        .method_8132(class_3956.field_17546,
                                new net.minecraft.class_1277(dropStack),
                                world)
                        .ifPresent(entry -> {
                            class_1799 result = entry.comp_1933().method_8110(world.method_30349()).method_7972();
                            result.method_7939(dropStack.method_7947());
                            drop.method_6979(result);
                        });
            }
        }

        // === REPLANT : replante les cultures ===
        int replantLvl = class_1890.method_8225(ModEnchantments.REPLANT, tool);
        if (replantLvl > 0) {
            if (state.method_26204() instanceof class_2302 crop) {
                if (crop.method_9825(state)) {
                    world.method_8501(pos, crop.method_9828(0));
                }
            }
        }
    }

    private List<class_2338> getNeighbors(class_2338 pos) {
        List<class_2338> neighbors = new ArrayList<>();
        for (int x = -1; x <= 1; x++)
            for (int y = -1; y <= 1; y++)
                for (int z = -1; z <= 1; z++)
                    if (x != 0 || y != 0 || z != 0)
                        neighbors.add(pos.method_10069(x, y, z));
        return neighbors;
    }

    private List<class_2338> getNeighborsAndUp(class_2338 pos) {
        List<class_2338> neighbors = new ArrayList<>();
        // 6 directions + haut prioritaire
        neighbors.add(pos.method_10084());
        neighbors.add(pos.method_10095());
        neighbors.add(pos.method_10072());
        neighbors.add(pos.method_10078());
        neighbors.add(pos.method_10067());
        neighbors.add(pos.method_10095().method_10084());
        neighbors.add(pos.method_10072().method_10084());
        neighbors.add(pos.method_10078().method_10084());
        neighbors.add(pos.method_10067().method_10084());
        return neighbors;
    }
}
